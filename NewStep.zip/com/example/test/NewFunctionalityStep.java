package com.example.test;

import org.apache.log4j.Logger;
import org.apache.log4j.LogManager;
import org.w3c.dom.Element;

import com.itko.lisa.test.TestCase;
import com.itko.lisa.test.TestDefException;
import com.itko.lisa.test.TestNode;
import com.itko.util.CloneImplemented;
import com.itko.util.XMLUtils;

/**
 *
 * @author <a href="mailto:mike.gavaghan@ca.com">Mike Gavaghan</a>
 */
public class NewFunctionalityStep extends TestNode implements CloneImplemented
{
   /** Our logger */
   static private final Logger LOG = LogManager.getLogger(NewFunctionalityStep.class);

   /**
    * Get the type name.
    */
   @Override
   public String getTypeName() throws Exception
   {
      // TODO Provide a step type name
      return "NewFunctionality";
   }

   /**
    * Initialize from a test file.
    */
   @Override
   public void initialize(TestCase testCase, Element elem) throws TestDefException
   {
      // setCommand(XMLUtils.findChildGetItsText(elem, "command"));
   }
}
