package org.gavaghan.devtest.step;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.itko.lisa.editor.CustomEditor;

/**
 *
 * @author <a href="mailto:mike@gavaghan.org">Mike Gavaghan</a>
 */
public class SaveToFileEditor extends CustomEditor
{
   /** Initialized flag. */
  private boolean mInit = false;

   /** Filename */
   private JTextField mFilename = new JTextField();

   /** Binary */
   private JCheckBox mBinary = new JCheckBox();

   /** Encoding */
   private JTextField mEncoding = new JTextField();

   /** Content */
   private JTextField mContent = new JTextField();

   /**
    * Get Filename.
    *
    * @return Filename
    */
   public JTextField getFilename()
   {
      return mFilename;
   }

   /**
    * Get Binary.
    *
    * @return Binary
    */
   public JCheckBox getBinary()
   {
      return mBinary;
   }

   /**
    * Get Encoding.
    *
    * @return Encoding
    */
   public JTextField getEncoding()
   {
      return mEncoding;
   }

   /**
    * Get Content.
    *
    * @return Content
    */
   public JTextField getContent()
   {
      return mContent;
   }

   /*
    * (non-Javadoc)
    * @see com.itko.lisa.editor.CustomEditor#isEditorValid()
    */
   @Override
   public String isEditorValid()
   {
      if (mFilename.getText().trim().length() == 0) return "Please specify a Filename";
      if (mEncoding.getText().trim().length() == 0) return "Please specify a Encoding";
      if (mContent.getText().trim().length() == 0) return "Please specify a Content";
      return null;
   }

   /*
    * (non-Javadoc)
    * @see com.itko.lisa.editor.CustomEditor#save()
    */
   @Override
   public void save()
   {
      SaveToFileController controller = (SaveToFileController) getController();
      controller.getTestCaseInfo().getTestExec().saveNodeResponse(controller.getName(), controller.getRet());
      SaveToFileStep step = (SaveToFileStep) controller.getAttribute(SaveToFileController.STEP_KEY);

      step.setFilename(getFilename().getText());
      step.setBinary(getBinary().isSelected() ? Boolean.TRUE : Boolean.FALSE);
      step.setEncoding(getEncoding().getText());
      step.setContent(getContent().getText());
   }

   /*
    * (non-Javadoc)
    * @see com.itko.lisa.editor.CustomEditor#display()
    */
   @Override
   public void display()
   {
      setupEditor();

      SaveToFileController controller = (SaveToFileController) getController();
      SaveToFileStep step = (SaveToFileStep) controller.getAttribute(SaveToFileController.STEP_KEY);

      getFilename().setText(step.getFilename());
      getBinary().setSelected(step.getBinary().booleanValue());
      getEncoding().setText(step.getEncoding());
      getContent().setText(step.getContent());
   }

   /**
    * Build the UI.
    */
   private void setupEditor()
   {
      if (mInit)  return;
      
      mInit = true;

      GridBagConstraints gbc;

      // build the main editor panel
      JPanel mainPanel = new JPanel(new GridBagLayout());
      setMinimumSize(new Dimension(300,300));
      
      // add Filename label
      gbc = new GridBagConstraints();
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.gridwidth = 1;
      gbc.weightx = 0;
      gbc.weighty = 0;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      mainPanel.add(new JLabel("Filename: "), gbc);

      // add Filename to main panel
      gbc = new GridBagConstraints();
      gbc.gridx = 1;
      gbc.gridy = 0;
      gbc.gridwidth = 1;
      gbc.weightx = 1;
      gbc.weighty = 0;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      mainPanel.add(mFilename, gbc);

      // add Binary label
      gbc = new GridBagConstraints();
      gbc.gridx = 0;
      gbc.gridy = 1;
      gbc.gridwidth = 1;
      gbc.weightx = 0;
      gbc.weighty = 0;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      mainPanel.add(new JLabel("Binary: "), gbc);

      // add Binary to main panel
      gbc = new GridBagConstraints();
      gbc.gridx = 1;
      gbc.gridy = 1;
      gbc.gridwidth = 1;
      gbc.weightx = 1;
      gbc.weighty = 0;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      mainPanel.add(mBinary, gbc);

      // add Encoding label
      gbc = new GridBagConstraints();
      gbc.gridx = 0;
      gbc.gridy = 2;
      gbc.gridwidth = 1;
      gbc.weightx = 0;
      gbc.weighty = 0;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      mainPanel.add(new JLabel("Encoding: "), gbc);

      // add Encoding to main panel
      gbc = new GridBagConstraints();
      gbc.gridx = 1;
      gbc.gridy = 2;
      gbc.gridwidth = 1;
      gbc.weightx = 1;
      gbc.weighty = 0;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      mainPanel.add(mEncoding, gbc);

      // add Content label
      gbc = new GridBagConstraints();
      gbc.gridx = 0;
      gbc.gridy = 3;
      gbc.gridwidth = 1;
      gbc.weightx = 0;
      gbc.weighty = 0;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      mainPanel.add(new JLabel("Content: "), gbc);

      // add Content to main panel
      gbc = new GridBagConstraints();
      gbc.gridx = 1;
      gbc.gridy = 3;
      gbc.gridwidth = 1;
      gbc.weightx = 1;
      gbc.weighty = 0;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      mainPanel.add(mContent, gbc);
 
      // add main panel to editor
      this.setLayout(new GridBagLayout());
      gbc = new GridBagConstraints();
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.weightx = 1;
      gbc.weighty = 1;
      gbc.anchor = GridBagConstraints.NORTHWEST;
      gbc.fill = GridBagConstraints.HORIZONTAL;
      add(mainPanel, gbc);
   }
}
